
using Microsoft.Data.SqlClient;
namespace Laboratorio3MiguelMarroquinVB14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string u = textBox1.Text.Trim();
            string p = textBox2.Text;
            if (string.IsNullOrEmpty(p))
            {
                MessageBox.Show("Ingresa la contrase�a.");
                return;
            }
            string cs = @"Data Source=PCMIKE\SQLEXPRESS;Initial Catalog=TextilesHogar;Integrated Security=True;TrustServerCertificate=True;";
            try
            {
                using (var cn = new SqlConnection(cs))
                using (var cmd = new SqlCommand("SELECT COUNT(1) FROM logins WHERE Usuario=@u AND Clave=@p", cn))
                {
                    cmd.Parameters.AddWithValue("@u", u);
                    cmd.Parameters.AddWithValue("@p", p);
                    cn.Open();
                    int ok = (int)cmd.ExecuteScalar();
                    if (ok == 1)
                    {
                        var f2 = new Form2();
                        f2.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Contrase�a incorrecta.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de conexi�n:\n" + ex.Message);
            }
        }
    }
}
