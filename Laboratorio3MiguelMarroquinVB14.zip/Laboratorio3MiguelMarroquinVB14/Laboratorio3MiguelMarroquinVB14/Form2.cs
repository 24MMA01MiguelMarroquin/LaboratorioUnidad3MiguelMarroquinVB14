﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Laboratorio3MiguelMarroquinVB14
{
    public partial class Form2 : Form
    {
        readonly string cs = @"Data Source=PCMIKE\SQLEXPRESS;Initial Catalog=TextilesHogar;Integrated Security=True;TrustServerCertificate=True;";
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = textBox1.Text.Trim();
            string producto = textBox2.Text.Trim();
            string sPrecio = textBox3.Text.Trim();
            string sStock = textBox4.Text.Trim();
            string genero = textBox5.Text.Trim().ToUpper();

            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(producto) ||
                string.IsNullOrWhiteSpace(sPrecio) || string.IsNullOrWhiteSpace(sStock) ||
                string.IsNullOrWhiteSpace(genero))
            { MessageBox.Show("Completa todos los campos."); return; }

            if (!decimal.TryParse(sPrecio, out decimal precio) || !int.TryParse(sStock, out int stock))
            { MessageBox.Show("Precio o Stock inválidos."); return; }

            if (genero != "M" && genero != "F")
            { MessageBox.Show("Género debe ser M o F."); return; }

            string cs = @"Data Source=PCMIKE\SQLEXPRESS;Initial Catalog=TextilesHogar;Integrated Security=True;TrustServerCertificate=True;";

            try
            {
                using (var cn = new SqlConnection(cs))
                using (var cmd = new SqlCommand(
                    "INSERT INTO productos (Nombre, Producto, Precio, Stock, Genero) VALUES (@n,@pr,@p,@s,@g)", cn))
                {
                    cmd.Parameters.AddWithValue("@n", nombre);
                    cmd.Parameters.AddWithValue("@pr", producto);
                    cmd.Parameters.AddWithValue("@p", precio);
                    cmd.Parameters.AddWithValue("@s", stock);
                    cmd.Parameters.AddWithValue("@g", genero);

                    cn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Producto guardado.");
                CargarTabla();
                textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear(); textBox5.Clear();
                textBox1.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar:\n" + ex.Message);
            }
        }
        private void CargarTabla()
        {
            using var cn = new SqlConnection(cs);
            using var da = new SqlDataAdapter("SELECT IdProducto, Nombre, Producto, Precio, Stock, Genero FROM dbo.productos", cn);
            var dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            CargarTabla();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox6.Text.Trim(), out int id))
            {
                MessageBox.Show("Ingresa un ID válido (número entero).");
                return;
            }

            try
            {
                using var cn = new SqlConnection(cs);
                using var cmd = new SqlCommand(
                    "SELECT IdProducto, Nombre, Producto, Precio, Stock, Genero FROM dbo.productos WHERE IdProducto=@id", cn);
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                using var rd = cmd.ExecuteReader();

                if (rd.Read())
                {
                    // Cargar en los textbox
                    textBox1.Text = rd["Nombre"].ToString();
                    textBox2.Text = rd["Producto"].ToString();
                    textBox3.Text = Convert.ToDecimal(rd["Precio"]).ToString();
                    textBox4.Text = Convert.ToInt32(rd["Stock"]).ToString();
                    textBox5.Text = rd["Genero"].ToString();
                }
                else
                {
                    MessageBox.Show("No se encontró el ID especificado.");
                    textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear(); textBox5.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al leer:\n" + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox6.Text.Trim(), out int id))
            {
                MessageBox.Show("Ingresa un ID válido.");
                return;
            }

            string nombre = textBox1.Text.Trim();
            string producto = textBox2.Text.Trim();
            string sPrecio = textBox3.Text.Trim();
            string sStock = textBox4.Text.Trim();
            string genero = textBox5.Text.Trim().ToUpper();

            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(producto) ||
                !decimal.TryParse(sPrecio, out decimal precio) ||
                !int.TryParse(sStock, out int stock) ||
                (genero != "M" && genero != "F"))
            {
                MessageBox.Show("Revisa los datos (precio/stock válidos y género M o F).");
                return;
            }
            try
            {
                using (var cn = new SqlConnection(cs))
                using (var cmd = new SqlCommand(
                    "UPDATE dbo.productos SET Nombre=@n, Producto=@pr, Precio=@p, Stock=@s, Genero=@g WHERE IdProducto=@id", cn))
                {
                    cmd.Parameters.AddWithValue("@n", nombre);
                    cmd.Parameters.AddWithValue("@pr", producto);
                    cmd.Parameters.AddWithValue("@p", precio);
                    cmd.Parameters.AddWithValue("@s", stock);
                    cmd.Parameters.AddWithValue("@g", genero);
                    cmd.Parameters.AddWithValue("@id", id);

                    cn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 0) MessageBox.Show("No existe ese ID.");
                    else { MessageBox.Show("Producto actualizado."); CargarTabla(); }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar:\n" + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox6.Text.Trim(), out int id))
            {
                MessageBox.Show("Ingresa un ID válido.");
                return;
            }

            if (MessageBox.Show($"¿Eliminar el producto ID {id}?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                using (var cn = new SqlConnection(cs))
                using (var cmd = new SqlCommand("DELETE FROM dbo.productos WHERE IdProducto=@id", cn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 0) MessageBox.Show("No existe ese ID.");
                    else
                    {
                        MessageBox.Show("Producto eliminado.");
                        CargarTabla();
                        textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear(); textBox5.Clear(); textBox6.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar:\n" + ex.Message);
            }
        }
    }
}
